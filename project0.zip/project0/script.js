const classNames = {
  TODO_ITEM: 'todo-container',
  TODO_CHECKBOX: 'todo-checkbox',
  TODO_TEXT: 'todo-text',
  TODO_DELETE: 'todo-delete',
}

var list = document.getElementById('todo-list');
var itemCountSpan = parseInt(document.getElementById('item-count').innerText);
var uncheckedCountSpan = parseInt(document.getElementById('unchecked-count').innerText);

function newTodo() {
  itemCountSpan +=1;
  uncheckedCountSpan +=1;
  document.getElementById('item-count').innerText = itemCountSpan;
  document.getElementById('unchecked-count').innerText = uncheckedCountSpan;
   
	  TODO_ITEM: itemCountSpan.toString();
	  TODO_CHECKBOX: uncheckedCountSpan.toString();
	  TODO_TEXT: 'Hola ' + itemCountSpan.toString(); 
	  TODO_DELETE: 'todo-delete';
	
	  document.getElementById('todo-list').innerHTML += '<li id="todo-item'+itemCountSpan.toString()+'" class="todo-item">'+ itemCountSpan.toString() +' - '+ 
	  uncheckedCountSpan.toString() + ' - ' + 'Hola ' + itemCountSpan.toString()+ '<button id="btn'+itemCountSpan.toString()+'" onclick=deleteTask(this.id)>Eliminar</button></li>';
}

function deleteTask(item){
	var id = 'todo-item' + item.replace('btn', '');
	var li = document.getElementById(id); 
	li.remove();
	itemCountSpan -=1;
  uncheckedCountSpan -=1;
  document.getElementById('item-count').innerText = itemCountSpan;
  document.getElementById('unchecked-count').innerText = uncheckedCountSpan;
}
